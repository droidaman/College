# can loop over a range of integers. There are several forms:

for i in range(10):
  print "range(10):",i
print "----------------"

for i in range(12,18):
  print "range(12,18):",i
print "----------------"

for i in range(5,25,5):
  print "range(5,25,5):",i
print "----------------"

for i in [4,2,8,9,4,2,7,6]:
  print "range over an arbitrary list:",i
