for ((i=0; i-100; i++)); do
  java Proj 30.50.04.2.1.10000.pal.out < 30.50.04.2.1.10000.config
done
