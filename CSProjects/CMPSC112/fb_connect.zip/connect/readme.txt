Welcome to the Quick Start Facebook Connect PHP API library.


Before you can test this code you'll need to edit lib/config.php with the appropriate information.

See a working demo of this here ...
http://pakt.com/scripts/facebook/connect/

And read a tutorial about this library here ...
http://www.pakt.com/pakt/?id=5e17b48f5679ab47&t=How_to_add_Facebook_Connect_to_your_website_using_the_PHP_API


Facebook is a registered trademark of Facebook, Inc.
No warranty is made when using this software