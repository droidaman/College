package domcode;

//Interface for the domino.
public interface Domino {
	public void flip();
	public int getLeft();
	public int getRight();
}