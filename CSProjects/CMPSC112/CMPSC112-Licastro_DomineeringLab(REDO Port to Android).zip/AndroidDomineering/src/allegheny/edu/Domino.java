package allegheny.edu;

//Interface for the domino.
public interface Domino {
	public void flip();
	public int getLeft();
	public int getRight();
}