INSERT INTO `config` (`setting` ,`value`)VALUES ('mno', '5');
UPDATE `config` SET `value` = '2.2' WHERE CONVERT( `config`.`setting` USING utf8 ) = 'ver' LIMIT 1 ;
ALTER TABLE `posts_comments` ADD `vote` BIGINT( 20 ) NOT NULL;
ALTER TABLE `posts_comments` ADD `RID` BIGINT( 20 ) NOT NULL ;