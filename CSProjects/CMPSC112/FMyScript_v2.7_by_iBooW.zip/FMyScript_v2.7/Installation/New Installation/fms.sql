SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

-- --------------------------------------------------------

--
-- Table structure for table `administrators`
--

CREATE TABLE IF NOT EXISTS `administrators` (
  `ADMINID` bigint(20) NOT NULL auto_increment,
  `email` varchar(80) NOT NULL default '',
  `username` varchar(80) NOT NULL default '',
  `password` varchar(50) NOT NULL default '',
  PRIMARY KEY  (`ADMINID`),
  UNIQUE KEY `email` (`email`),
  UNIQUE KEY `username` (`username`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `administrators`
--

INSERT INTO `administrators` (`ADMINID`, `email`, `username`, `password`) VALUES
(1, 'webmaster@fmyscript.com', 'Admin', '3df84bf50227d40fec2db869643a6309');

-- --------------------------------------------------------

--
-- Table structure for table `advertisements`
--

CREATE TABLE IF NOT EXISTS `advertisements` (
  `AID` bigint(30) NOT NULL auto_increment,
  `description` varchar(200) NOT NULL default '',
  `code` text NOT NULL,
  `active` enum('1','0') NOT NULL default '1',
  PRIMARY KEY  (`AID`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `advertisements`
--

INSERT INTO `advertisements` (`AID`, `description`, `code`, `active`) VALUES
(1, '300 x 250 pixels', '<div style="width:300px; height:250px; border:1px solid #DFDFDF;" align="center"><br/><br/>Insert Your<br/>Advertisement Here</div>', '1'),
(2, '120 x 728 pixels', '<div style="width:120px; height:728px; border:1px solid #DFDFDF;" align="center"><br/><br/>Insert Your Advertisement Here</div>', '1'),
(3, '728 x 90 pixels', '<div style="width:728px; height:90px; border:1px solid #DFDFDF;" align="center"><br/><br/>Insert Your Advertisement Here</div>', '1'),
(4, '350 x 90 pixels', '<div style="width:350px; height:90px; border:1px solid #DFDFDF;" align="center"><br/><br/>Insert Your Advertisement Here</div>', '1'),
(5, '300 x 100 pixels', '<div style="width:300px; height:100px; border:1px solid #DFDFDF;" align="center"><br/><br/>Insert Your Advertisement Here</div>', '1');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE IF NOT EXISTS `categories` (
  `CATID` bigint(20) NOT NULL auto_increment,
  `name` varchar(120) NOT NULL default '',
  PRIMARY KEY  (`CATID`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`CATID`, `name`) VALUES
(1, 'Love'),
(2, 'Money'),
(3, 'Kids'),
(4, 'Work'),
(5, 'Health'),
(6, 'Sex'),
(7, 'Miscellaneous');

-- --------------------------------------------------------

--
-- Table structure for table `config`
--

CREATE TABLE IF NOT EXISTS `config` (
  `setting` varchar(60) NOT NULL default '',
  `value` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `config`
--

INSERT INTO `config` (`setting`, `value`) VALUES
('site_email', 'webmaster@yourdomain.com'),
('site_name', 'FMyScript'),
('max_syndicate_results', '25'),
('maximum_results', '1000000'),
('emailsender', 'Admin'),
('max_img_size', '200'),
('rand_stories', '10'),
('flop_stories', '10'),
('items_per_page', '10'),
('site_slogan', 'My something sucks but i don\\''t care'),
('approve_stories', '1'),
('metadescription', 'F My Script is the FMyLife.com clone script'),
('metakeywords', 'f my script, fmyscript, fmylife, clone'),
('top_stories', '10'),
('pub_mod', '1'),
('ver', '2.7');

-- --------------------------------------------------------

--
-- Table structure for table `members`
--

CREATE TABLE IF NOT EXISTS `members` (
  `USERID` bigint(20) NOT NULL auto_increment,
  `email` varchar(80) NOT NULL default '',
  `username` varchar(80) NOT NULL default '',
  `password` varchar(50) NOT NULL default '',
  `firstname` varchar(60) NOT NULL default '',
  `lastname` varchar(60) NOT NULL default '',
  `birthday` date NOT NULL default '0000-00-00',
  `gender` varchar(6) NOT NULL default '',
  `description` text NOT NULL,
  `city` varchar(80) NOT NULL default '',
  `country` varchar(100) NOT NULL default '',
  `yourviewed` int(20) NOT NULL default '0',
  `profileviews` int(20) NOT NULL default '0',
  `youviewed` bigint(20) NOT NULL default '0',
  `addtime` varchar(20) NOT NULL default '',
  `lastlogin` varchar(20) NOT NULL default '',
  `verified` char(1) NOT NULL default '0',
  `status` enum('1','0') NOT NULL default '1',
  `profilepicture` varchar(100) NOT NULL default '',
  `remember_me_key` varchar(32) default NULL,
  `remember_me_time` datetime default NULL,
  PRIMARY KEY  (`USERID`),
  UNIQUE KEY `email` (`email`),
  UNIQUE KEY `username` (`username`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `members_passcode`
--

CREATE TABLE IF NOT EXISTS `members_passcode` (
  `USERID` bigint(20) NOT NULL default '0',
  `code` varchar(30) NOT NULL default '',
  PRIMARY KEY  (`USERID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `members_passcode`
--


-- --------------------------------------------------------

--
-- Table structure for table `members_verifycode`
--

CREATE TABLE IF NOT EXISTS `members_verifycode` (
  `USERID` bigint(20) NOT NULL default '0',
  `code` varchar(30) NOT NULL default '',
  PRIMARY KEY  (`USERID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `members_visits`
--

CREATE TABLE IF NOT EXISTS `members_visits` (
  `ID` bigint(20) NOT NULL auto_increment,
  `PID` bigint(25) NOT NULL default '0',
  `VID` bigint(25) NOT NULL default '0',
  `time` varchar(20) NOT NULL default '',
  PRIMARY KEY  (`ID`),
  UNIQUE KEY `PID` (`PID`,`VID`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE IF NOT EXISTS `posts` (
  `PID` bigint(20) NOT NULL auto_increment,
  `USERID` bigint(20) NOT NULL default '0',
  `username` text NOT NULL,
  `gender` char(1) NOT NULL default '0',
  `story` text NOT NULL,
  `category` bigint(20) NOT NULL default '0',
  `email` varchar(80) NOT NULL default '',
  `time_added` varchar(20) default NULL,
  `date_added` date NOT NULL default '0000-00-00',
  `active` char(1) NOT NULL default '',
  `vote_yes` bigint(20) NOT NULL default '0',
  `vote_no` bigint(20) NOT NULL default '0',
  `last_viewed` varchar(20) NOT NULL default '',
  PRIMARY KEY  (`PID`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `posts_comments`
--

CREATE TABLE IF NOT EXISTS `posts_comments` (
  `CID` bigint(20) NOT NULL auto_increment,
  `PID` bigint(20) NOT NULL default '0',
  `USERID` bigint(20) NOT NULL default '0',
  `details` text NOT NULL,
  `time_added` varchar(20) NOT NULL default '',
  PRIMARY KEY  (`CID`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `posts_comments_reports`
--

CREATE TABLE IF NOT EXISTS `posts_comments_reports` (
  `RID` bigint(20) NOT NULL auto_increment,
  `CID` bigint(20) NOT NULL default '0',
  `date` date NOT NULL default '0000-00-00',
  `time` varchar(20) default NULL,
  PRIMARY KEY  (`RID`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `posts_favorited`
--

CREATE TABLE IF NOT EXISTS `posts_favorited` (
  `FID` bigint(20) NOT NULL auto_increment,
  `USERID` bigint(25) NOT NULL default '0',
  `PID` bigint(25) NOT NULL default '0',
  PRIMARY KEY  (`FID`),
  UNIQUE KEY `USERID` (`USERID`,`PID`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `posts_reports`
--

CREATE TABLE IF NOT EXISTS `posts_reports` (
  `RID` bigint(20) NOT NULL auto_increment,
  `PID` bigint(20) NOT NULL default '0',
  `date` date NOT NULL default '0000-00-00',
  `time` varchar(20) default NULL,
  PRIMARY KEY  (`RID`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `sendmail`
--

CREATE TABLE IF NOT EXISTS `sendmail` (
  `EID` varchar(50) NOT NULL default '',
  `subject` varchar(255) NOT NULL default '',
  `template` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`EID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `sendmail`
--

INSERT INTO `sendmail` (`EID`, `subject`, `template`) VALUES
('confirmemail', 'E-Mail Verification', 'sendmail/confirmemail.tpl'),
('sendnewpassword', 'Your new password for', 'sendmail/sendnewpassword.tpl'),
('welcomeemail', 'Welcome to', 'sendmail/welcomeemail.tpl'),
('confirmforgotpass', 'Reset Password Link', 'sendmail/confirmforgotpass.tpl');

-- --------------------------------------------------------

--
-- Table structure for table `static`
--

CREATE TABLE IF NOT EXISTS `static` (
  `ID` bigint(30) NOT NULL auto_increment,
  `title` varchar(255) NOT NULL default '',
  `value` blob NOT NULL,
  PRIMARY KEY  (`ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `static`
--

INSERT INTO `static` (`ID`, `title`, `value`) VALUES
(1, 'Terms Of Use', 0x496e7365727420796f7572207465726d73206f662075736520696e666f726d6174696f6e20686572652e3c62723e3c62723e0d0a0d0a48544d4c2069732061636365707465642e),
(2, 'Privacy Policy', 0x496e7365727420796f7572207072697661637920706f6c69637920696e666f726d6174696f6e20686572652e3c62723e3c62723e0d0a0d0a48544d4c2069732061636365707465642e),
(3, 'About Us', 0x496e7365727420796f75722061626f757420757320696e666f726d6174696f6e20686572652e3c62723e3c62723e0d0a0d0a48544d4c2069732061636365707465642e),
(4, 'Advertising', 0x496e7365727420796f7572206164766572746973696e6720696e666f726d6174696f6e20686572652e3c62723e3c62723e0d0a0d0a48544d4c2069732061636365707465642e),
(5, 'Contact Us', 0x496e7365727420796f757220636f6e7461637420757320696e666f726d6174696f6e20686572652e3c62723e3c62723e0d0a0d0a48544d4c2069732061636365707465642e);

INSERT INTO `config` (`setting` ,`value`)VALUES ('climit', '300');
INSERT INTO `config` (`setting` ,`value`)VALUES ('myes', '5');
ALTER TABLE `posts` ADD `mod_yes` BIGINT( 20 ) NOT NULL DEFAULT '0', ADD `mod_no` BIGINT( 20 ) NOT NULL DEFAULT '0';
ALTER TABLE `posts` ADD `pip` VARCHAR( 20 ) NOT NULL ;
ALTER TABLE `posts` ADD `pip2` VARCHAR( 20 ) NOT NULL ;

CREATE TABLE IF NOT EXISTS `bans_ips` (
  `ip` varchar(20) NOT NULL,
  UNIQUE KEY `ip` (`ip`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

ALTER TABLE `members` ADD `ip` VARCHAR( 20 ) NOT NULL ;
ALTER TABLE `members` ADD `lip` VARCHAR( 20 ) NOT NULL ;

CREATE TABLE IF NOT EXISTS `bans_words` (
  `word` varchar(100) NOT NULL,
  UNIQUE KEY `word` (`word`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO `config` (`setting` ,`value`)VALUES ('mno', '5');
ALTER TABLE `posts_comments` ADD `vote` BIGINT( 20 ) NOT NULL;
ALTER TABLE `posts_comments` ADD `RID` BIGINT( 20 ) NOT NULL ;

CREATE TABLE IF NOT EXISTS `subscribe` (
  `ID` bigint(20) NOT NULL auto_increment,
  `PID` bigint(20) NOT NULL default '0',
  `USERID` bigint(20) NOT NULL default '0',
  PRIMARY KEY  (`ID`),
  UNIQUE KEY `PID` (`PID`,`USERID`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

INSERT INTO `config` (`setting` ,`value`)VALUES ('twitter', 'Scriptolution');

CREATE TABLE `messages_inbox` (
  `MID` bigint(20) NOT NULL auto_increment,
  `MSGTO` bigint(20) NOT NULL default '0',
  `MSGFROM` bigint(20) NOT NULL default '0',
  `subject` varchar(100) NOT NULL default '',
  `message` varchar(200) NOT NULL default '',
  `time` varchar(20) NOT NULL default '',
  `unread` char(1) NOT NULL default '1',
  PRIMARY KEY  (`MID`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

INSERT INTO `config` (`setting`, `value`) VALUES ('FACEBOOK_APP_ID', ''), ('FACEBOOK_SECRET', ''), ('enable_fc', '0');