UPDATE `config` SET `value` = '2.5' WHERE CONVERT( `config`.`setting` USING utf8 ) = 'ver' LIMIT 1 ;

CREATE TABLE `messages_inbox` (
  `MID` bigint(20) NOT NULL auto_increment,
  `MSGTO` bigint(20) NOT NULL default '0',
  `MSGFROM` bigint(20) NOT NULL default '0',
  `subject` varchar(100) NOT NULL default '',
  `message` varchar(200) NOT NULL default '',
  `time` varchar(20) NOT NULL default '',
  `unread` char(1) NOT NULL default '1',
  PRIMARY KEY  (`MID`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;
