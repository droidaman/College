
UPDATE `config` SET `value` = '1.3' WHERE CONVERT( `config`.`setting` USING utf8 ) = 'ver' LIMIT 1 ;