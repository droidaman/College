UPDATE `config` SET `value` = '2.3' WHERE CONVERT( `config`.`setting` USING utf8 ) = 'ver' LIMIT 1 ;

CREATE TABLE IF NOT EXISTS `subscribe` (
  `ID` bigint(20) NOT NULL auto_increment,
  `PID` bigint(20) NOT NULL default '0',
  `USERID` bigint(20) NOT NULL default '0',
  PRIMARY KEY  (`ID`),
  UNIQUE KEY `PID` (`PID`,`USERID`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;