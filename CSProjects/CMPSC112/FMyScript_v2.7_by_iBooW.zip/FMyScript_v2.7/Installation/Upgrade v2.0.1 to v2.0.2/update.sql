
UPDATE `config` SET `value` = '2.0.2' WHERE CONVERT( `config`.`setting` USING utf8 ) = 'ver' LIMIT 1 ;