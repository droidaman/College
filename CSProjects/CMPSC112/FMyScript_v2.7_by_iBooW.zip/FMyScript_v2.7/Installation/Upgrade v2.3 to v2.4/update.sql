UPDATE `config` SET `value` = '2.4' WHERE CONVERT( `config`.`setting` USING utf8 ) = 'ver' LIMIT 1 ;
INSERT INTO `config` (`setting` ,`value`)VALUES ('twitter', 'Scriptolution');