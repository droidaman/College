
UPDATE `config` SET `value` = '2.0' WHERE CONVERT( `config`.`setting` USING utf8 ) = 'ver' LIMIT 1 ;
INSERT INTO `config` (`setting` ,`value`)VALUES ('climit', '300');
INSERT INTO `config` (`setting` ,`value`)VALUES ('myes', '5');
ALTER TABLE `posts` ADD `mod_yes` BIGINT( 20 ) NOT NULL DEFAULT '0', ADD `mod_no` BIGINT( 20 ) NOT NULL DEFAULT '0';
ALTER TABLE `posts` ADD `pip` VARCHAR( 20 ) NOT NULL ;
ALTER TABLE `posts` ADD `pip2` VARCHAR( 20 ) NOT NULL ;

CREATE TABLE IF NOT EXISTS `bans_ips` (
  `ip` varchar(20) NOT NULL,
  UNIQUE KEY `ip` (`ip`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

ALTER TABLE `members` ADD `ip` VARCHAR( 20 ) NOT NULL ;
ALTER TABLE `members` ADD `lip` VARCHAR( 20 ) NOT NULL ;

CREATE TABLE IF NOT EXISTS `bans_words` (
  `word` varchar(100) NOT NULL,
  UNIQUE KEY `word` (`word`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;