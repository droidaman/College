UPDATE `config` SET `value` = '2.6.1' WHERE CONVERT( `config`.`setting` USING utf8 ) = 'ver' LIMIT 1 ;
