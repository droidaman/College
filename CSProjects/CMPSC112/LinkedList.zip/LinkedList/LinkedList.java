/**
 * Write a description of interface List here.
 * 
 * @author (Braden Licastro) 
 * @version (20110227)
 */

public class LinkedList<E> {
    private Node<E> first;
    private int listSize;

    public LinkedList () {
        first = null;
        listSize = 0;
    }

    public void add (E item) {
        // If the Node called 'first' is null,
        // then there must be no nodes in this list.
        //Therefore, it must be empty.
        if (first == null) {
            first = new Node<E>(item, null);
        } else {
            addToEnd(item, first);
        }
        listSize++;
    }

    private void addToEnd(E item, Node<E> n){
        if (n.getNext() == null){
            Node<E> last = new Node<E>(item, null);
            n.setNext(last);
        }else{
            addToEnd(item, n.getNext());
        }
    }

    public boolean contains (E myItem) {
        if (isEmpty()) {
            return false;
        } else {
            return privContains(myItem, first);
        }
    }

    private boolean privContains(E myItem, Node<E> n){
        if (n == null){
            return false;
        } else if(myItem == n.getItem()){
            return true;
        } else {
            return privContains(myItem, n.getNext());
        }
    }

    public E get (int index) {
        Node<E> n = first;

        for (int i=0; i <= index; i++){
            n.getNext();
            if(i == index){
                return ((E)n);
            }
        }
    }

        public boolean isEmpty() {
            return first == null;
        }

        public E remove (int index) {
            Node<E> n = first;

            for (int i=0; i <= index; i++){
                n.getNext();
                if(i == index){
                   n.remove();
                }
            }
            first = Node<E> n;
        }

        public void set (int index, E item) {
            Node<E> n = first;

            for (int i=0; i <= index; i++){
                n.getNext();
                if(i == index){
                    first = new Node<E>(item, null);
                }
            }

            first = Node<E> n;
        }

        public int size() {
            return listSize;
        }
    }