
/**
 * Write a description of class Book here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Book
{
    // instance variables - replace the example below with your own
    private String name;

    /**
     * Constructor for objects of class Book
     */
    public Book(String name)
    {
        // initialise instance variables
        this.name = name;
    }

}
