
/**
 * Write a description of class Meat here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Meat
{
    // instance variables - replace the example below with your own
    /**
     * Constructor for objects of class Meat
     */
    public Meat()
    {
        // initialise instance variables
     }

}
