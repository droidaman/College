
/**
 * Write a description of class Cheese here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Cheese
{
    // instance variables - replace the example below with your own

    /**
     * Constructor for objects of class Cheese
     */
    public Cheese()
    {
        // initialise instance variables
    }

}
