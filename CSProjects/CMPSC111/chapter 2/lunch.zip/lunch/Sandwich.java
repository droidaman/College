
/**
 * Write a description of class Sandwich here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Sandwich
{
    // instance variables - replace the example below with your own


    /**
     * Constructor for objects of class Sandwich
     */
    public Sandwich()
    {
        // initialise instance variables
 
    }
}
